import React, { useState } from 'react';
import { X, CheckCircle, ArrowRight, Clock, MessageCircle } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    interest: 'Custom Project',
    notes: '',
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({ name: '', email: '', phone: '', interest: 'Custom Project', notes: '' });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md transition-all">
      <div
        className="relative w-full max-w-lg bg-[#FAF6F0] border border-[#DECDBA] rounded-2xl p-6 sm:p-8 shadow-2xl text-[#1C1917] max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#78716C] hover:text-[#1C1917] rounded-full hover:bg-[#EDE5DB] transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-8">
            <div className="w-14 h-14 bg-[#EDE5DB] rounded-full flex items-center justify-center mx-auto mb-4 border border-[#DECDBA]">
              <CheckCircle className="w-8 h-8 text-[#1C1917]" />
            </div>
            <h3 className="text-2xl font-bold tracking-tight mb-2 text-[#1C1917]">Message Received</h3>
            <p className="text-[#57534E] text-sm max-w-xs mx-auto mb-6">
              Thank you for reaching out to Unique Crafts Design. Our studio artisan will be in touch with you shortly.
            </p>
            <button
              onClick={handleReset}
              className="px-6 py-2.5 rounded-full bg-[#1C1917] text-white font-semibold text-sm hover:bg-[#292524] transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
                Unique Crafts Design Studio
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1 text-[#1C1917]">
                Get In Touch
              </h2>
              <p className="text-sm text-[#57534E] mt-1">
                Tell us about your space, custom piece ideas, or questions about our handcrafted natural wood collections.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#44403C] mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Mitchell"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2.5 bg-[#F5ECE0] border border-[#DECDBA] rounded-xl text-[#1C1917] text-sm focus:outline-none focus:border-[#1C1917] transition-colors placeholder:text-[#A89A88]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#44403C] mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="alex@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-2.5 bg-[#F5ECE0] border border-[#DECDBA] rounded-xl text-[#1C1917] text-sm focus:outline-none focus:border-[#1C1917] transition-colors placeholder:text-[#A89A88]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#44403C] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+254 7XX XXX XXX"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-2.5 bg-[#F5ECE0] border border-[#DECDBA] rounded-xl text-[#1C1917] text-sm focus:outline-none focus:border-[#1C1917] transition-colors placeholder:text-[#A89A88]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#44403C] mb-1">
                  Collection or Project Interest
                </label>
                <select
                  value={formData.interest}
                  onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                  className="w-full px-4 py-2.5 bg-[#F5ECE0] border border-[#DECDBA] rounded-xl text-[#1C1917] text-sm focus:outline-none focus:border-[#1C1917] transition-colors cursor-pointer"
                >
                  <option value="Custom Project">Custom Project / Bespoke Furniture</option>
                  <option value="Wine Holders">Wine Holders & Entertaining</option>
                  <option value="Natural Wood Mirrors">Natural Wood Mirrors</option>
                  <option value="Wooden Wall Art">Wooden Wall Art</option>
                  <option value="General Inquiry">General Studio Inquiry</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#44403C] mb-1">Project Details & Ideas</label>
                <textarea
                  rows={3}
                  placeholder="Share dimensions, preferred timber types, room setting, or specific inspiration..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-4 py-2.5 bg-[#F5ECE0] border border-[#DECDBA] rounded-xl text-[#1C1917] text-sm focus:outline-none focus:border-[#1C1917] transition-colors placeholder:text-[#A89A88] resize-none"
                />
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <div className="flex items-center gap-1.5 text-xs text-[#78716C] order-2 sm:order-1">
                  <Clock className="w-3.5 h-3.5 text-[#1C1917] shrink-0" />
                  <span className="font-medium">We reply within 24 hours</span>
                </div>
                <button
                  type="submit"
                  className="w-full sm:w-auto px-6 py-2.5 bg-[#1C1917] text-white font-semibold text-sm rounded-full hover:bg-[#292524] transition-colors flex items-center justify-center gap-2 group cursor-pointer shadow order-1 sm:order-2"
                >
                  <span>Send Message</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                </button>
              </div>
            </form>

            {/* WhatsApp Alternative Action Under The Form */}
            <div className="mt-5 pt-4 border-t border-[#DECDBA]/80">
              <a
                href="https://wa.me/254XXXXXXXXX"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2.5 py-3 px-5 rounded-full bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/40 text-[#075E54] hover:text-[#128C7E] font-bold text-sm transition-all duration-200 cursor-pointer shadow-sm group"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366] fill-[#25D366]" />
                <span>Or chat on WhatsApp</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 text-[#075E54]" />
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
