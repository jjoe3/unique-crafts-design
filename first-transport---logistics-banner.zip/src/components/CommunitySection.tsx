import React from 'react';
import { ArrowRight, Users, TreePine, Sparkles, Recycle, HeartHandshake } from 'lucide-react';
import { useInView } from '../hooks/useInView.ts';

interface CommunitySectionProps {
  onGetInTouchClick?: () => void;
}

export const CommunitySection: React.FC<CommunitySectionProps> = ({ onGetInTouchClick }) => {
  const { ref, isInView } = useInView<HTMLElement>({ threshold: 0.08 });

  const commitments = [
    {
      title: 'Supporting Local Artisans',
      description:
        'Encouraging local woodworkers and craftspeople to develop their skills and showcase their talent.',
      icon: Users,
    },
    {
      title: 'Preserving Natural Beauty',
      description:
        'Giving wood a new purpose by transforming its unique grain, textures, and natural shapes into functional art.',
      icon: TreePine,
    },
    {
      title: 'Sharing Craftsmanship',
      description:
        'Inspiring the next generation through woodworking knowledge, creative collaboration, and hands-on learning.',
      icon: Sparkles,
    },
    {
      title: 'Responsible Woodcraft',
      description:
        'Promoting thoughtful material use and reducing waste by making the most of every piece of wood.',
      icon: Recycle,
    },
  ];

  return (
    <section
      ref={ref}
      id="community"
      className="relative w-full py-16 sm:py-24 md:py-32 px-4 sm:px-8 md:px-16 lg:px-20 border-t border-[#D6C7B2] overflow-hidden select-none text-[#1C1917]"
      style={{ backgroundColor: '#EDE5DB' }}
    >
      <div
        className={`max-w-7xl mx-auto transition-all duration-700 ease-out transform ${
          isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        {/* Header / Intro */}
        <div className="text-left max-w-3xl mb-12 sm:mb-16 lg:mb-20">
          <div className="flex items-center gap-3 mb-3 sm:mb-4">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-[0.25em] text-[#1C1917]">
              Community
            </span>
            <span className="h-[1px] w-8 bg-[#A89A88]" />
            <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
              Unique Crafts Design
            </span>
          </div>

          <h2 className="banner-heading text-3xl sm:text-4xl lg:text-[60px] font-extrabold text-[#1C1917] tracking-tight leading-[1.1] mb-4 sm:mb-6">
            Community
          </h2>

          <p className="banner-subheading text-[14.5px] sm:text-base lg:text-lg text-[#44403C] font-normal leading-relaxed">
            At Unique Crafts Design, we believe great craftsmanship goes beyond creating beautiful wooden pieces — it is about preserving nature, sharing skills, and building stronger communities. We celebrate traditional woodworking techniques, support local craftsmanship, and turn naturally sourced wood into timeless creations that bring people together.
          </p>
        </div>

        {/* Our Commitments Grid */}
        <div className="mb-12 sm:mb-16">
          <div className="flex items-center gap-2 mb-6 sm:mb-8">
            <HeartHandshake className="w-5 h-5 text-[#1C1917]" />
            <h3 className="text-sm sm:text-base md:text-lg uppercase tracking-[0.2em] font-bold text-[#1C1917]">
              Our Commitments
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
            {commitments.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  style={{ transitionDelay: `${idx * 100 + 100}ms` }}
                  className={`p-5 sm:p-7 rounded-2xl bg-[#FAF6F0] border border-[#DECDBA] hover:border-[#B59F85] transition-all duration-700 ease-out text-left shadow-sm group transform ${
                    isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                  }`}
                >
                  <div className="flex items-start gap-3.5 sm:gap-4">
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#EDE5DB] border border-[#DECDBA] flex items-center justify-center shrink-0 group-hover:border-[#1C1917] transition-colors">
                      <Icon className="w-4 h-4 sm:w-5 sm:h-5 text-[#1C1917]" />
                    </div>
                    <div>
                      <h4 className="banner-heading text-base sm:text-lg lg:text-xl font-bold text-[#1C1917] tracking-tight mb-1 sm:mb-2">
                        {item.title}
                      </h4>
                      <p className="banner-subheading text-xs sm:text-sm text-[#57534E] leading-relaxed font-normal">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Closing Banner & Action */}
        <div
          style={{ transitionDelay: '350ms' }}
          className={`p-6 sm:p-10 lg:p-12 rounded-2xl bg-[#F5ECE0] border border-[#DECDBA] flex flex-col sm:flex-row items-center justify-between gap-5 sm:gap-6 text-center sm:text-left shadow-sm transition-all duration-700 ease-out transform ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <div>
            <span className="text-[10px] sm:text-xs uppercase tracking-widest text-[#78716C] font-semibold block mb-1">
              Craftsmanship Philosophy
            </span>
            <div className="banner-heading text-xl sm:text-2xl md:text-3xl font-extrabold text-[#1C1917] tracking-tight">
              Made by Nature. Finished by Hand.
            </div>
          </div>

          <button
            onClick={onGetInTouchClick}
            className="inline-flex items-center justify-center gap-3 bg-[#1C1917] text-white px-7 sm:px-8 py-3 sm:py-3.5 rounded-full font-bold text-xs sm:text-sm tracking-wide uppercase hover:bg-[#292524] transition-all duration-200 cursor-pointer shadow-lg group w-full sm:w-auto shrink-0"
          >
            <span>GET IN TOUCH</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  );
};
