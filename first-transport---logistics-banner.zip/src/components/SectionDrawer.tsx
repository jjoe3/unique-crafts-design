import React from 'react';
import { X, Award, Shield, Users, Briefcase, ChevronRight, Globe, Truck, MapPin } from 'lucide-react';

interface SectionDrawerProps {
  section: string | null;
  onClose: () => void;
  onOpenContact: () => void;
}

export const SectionDrawer: React.FC<SectionDrawerProps> = ({
  section,
  onClose,
  onOpenContact,
}) => {
  if (!section || section === 'Home' || section === 'Our Story' || section === 'Collections' || section === 'Community') return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm transition-opacity">
      <div
        className="w-full max-w-lg h-full bg-[#FAF6F0] border-l border-[#DECDBA] p-6 sm:p-8 flex flex-col justify-between overflow-y-auto text-[#1C1917] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <div className="flex items-center justify-between pb-6 border-b border-neutral-850">
            <div>
              <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">
                First Transport Overview
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1 text-white">
                {section}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-900 transition-colors"
              aria-label="Close drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="py-6 space-y-6">
            {section === 'About Us' && (
              <>
                <p className="text-sm text-neutral-300 leading-relaxed">
                  First Transport is a premier Australian haulage and freight logistics partner, specializing in complex, high-risk freight movements and heavy machinery haulage for the resources, mining, and civil infrastructure sectors.
                </p>
                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 flex items-start gap-3">
                    <Shield className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-white">Safety Uncompromised</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Tier-1 health, safety, and environmental standards certified across all operations.
                      </p>
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 flex items-start gap-3">
                    <Users className="w-5 h-5 text-white shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-white">Community & First Nations Inclusion</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Deep indigenous employment pathways and sustainable local procurement.
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {section === 'Expertise' && (
              <>
                <p className="text-sm text-neutral-300 leading-relaxed">
                  Our comprehensive transport fleet delivers precision capability across three distinct operational wings:
                </p>
                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Truck className="w-4 h-4 text-white" />
                      Heavy Haulage & Oversize
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">
                      Multi-axle platforms, steerable dollys, pilot vehicles, and route permit coordination.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Globe className="w-4 h-4 text-white" />
                      Nationwide Freight Solutions
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">
                      Scheduled B-double, road train, and tautliner services across critical state corridors.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-white" />
                      Earthmoving Machinery Relocation
                    </h4>
                    <p className="text-xs text-neutral-400 mt-1">
                      Turnkey mobilization and demobilization for heavy civil, mining, and quarry fleets.
                    </p>
                  </div>
                </div>
              </>
            )}

            {section === 'Careers' && (
              <>
                <p className="text-sm text-neutral-300 leading-relaxed">
                  We invest in our drivers, operations team, and maintenance specialists with industry-leading packages, modern equipment, and structured development programs.
                </p>
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800">
                  <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                    Current Openings
                  </span>
                  <ul className="mt-2 space-y-2 text-xs text-neutral-300">
                    <li className="flex items-center justify-between py-1 border-b border-neutral-800">
                      <span>MC Interstate Haulage Drivers</span>
                      <span className="text-neutral-400">Multiple Depots</span>
                    </li>
                    <li className="flex items-center justify-between py-1 border-b border-neutral-800">
                      <span>Heavy Vehicle Diesel Mechanics</span>
                      <span className="text-neutral-400">Perth / Brisbane</span>
                    </li>
                    <li className="flex items-center justify-between py-1">
                      <span>Logistics Dispatch Controller</span>
                      <span className="text-neutral-400">Head Office</span>
                    </li>
                  </ul>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenContact();
                    }}
                    className="w-full mt-4 py-2 bg-white text-black font-semibold text-xs rounded-lg hover:bg-neutral-200 transition-colors"
                  >
                    Apply Now
                  </button>
                </div>
              </>
            )}

            {section === 'Community' && (
              <>
                <p className="text-sm text-neutral-300 leading-relaxed">
                  At Unique Crafts Design, we believe great craftsmanship goes beyond creating beautiful wooden pieces — it is about preserving nature, sharing skills, and building stronger communities. We celebrate traditional woodworking techniques, support local craftsmanship, and turn naturally sourced wood into timeless creations that bring people together.
                </p>
                <div className="space-y-3 text-xs text-neutral-300">
                  <div className="text-white font-bold text-sm">Our Commitments:</div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800">
                    <span className="font-bold text-white block">Supporting Local Artisans</span>
                    <span className="text-neutral-400">Encouraging local woodworkers and craftspeople to develop their skills and showcase their talent.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800">
                    <span className="font-bold text-white block">Preserving Natural Beauty</span>
                    <span className="text-neutral-400">Giving wood a new purpose by transforming its unique grain, textures, and natural shapes into functional art.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800">
                    <span className="font-bold text-white block">Sharing Craftsmanship</span>
                    <span className="text-neutral-400">Inspiring the next generation through woodworking knowledge, creative collaboration, and hands-on learning.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800">
                    <span className="font-bold text-white block">Responsible Woodcraft</span>
                    <span className="text-neutral-400">Promoting thoughtful material use and reducing waste by making the most of every piece of wood.</span>
                  </div>
                </div>
                <div className="pt-2 text-white font-bold text-sm">
                  Made by Nature. Finished by Hand.
                </div>
              </>
            )}
          </div>
        </div>

        <div className="pt-6 border-t border-neutral-850 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-neutral-400 hover:text-white text-xs transition-colors"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onOpenContact();
            }}
            className="px-5 py-2 bg-white text-black font-semibold text-xs rounded-full hover:bg-neutral-200 transition-colors flex items-center gap-1.5"
          >
            <span>Request Quote</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
