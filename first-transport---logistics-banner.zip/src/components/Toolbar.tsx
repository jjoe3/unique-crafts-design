import React from 'react';
import {
  Download,
  Eye,
  FileCode,
  Sliders,
  Palette,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { BackgroundMode } from './Banner.tsx';

interface ToolbarProps {
  backgroundMode: BackgroundMode;
  onBackgroundModeChange: (mode: BackgroundMode) => void;
  aspectMode: 'contained-16-9' | 'full-viewport';
  onAspectModeChange: (mode: 'contained-16-9' | 'full-viewport') => void;
  isEditing: boolean;
  onToggleEdit: () => void;
  onDownloadPng: () => void;
  isDownloading: boolean;
  onOpenCompare: () => void;
  onOpenCode: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onJumpToStory?: () => void;
  onJumpToCollections?: () => void;
  onJumpToCommunity?: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  backgroundMode,
  onBackgroundModeChange,
  aspectMode,
  onAspectModeChange,
  isEditing,
  onToggleEdit,
  onDownloadPng,
  isDownloading,
  onOpenCompare,
  onOpenCode,
  isFullscreen,
  onToggleFullscreen,
  onJumpToStory,
  onJumpToCollections,
  onJumpToCommunity,
}) => {
  if (isFullscreen) {
    return (
      <button
        onClick={onToggleFullscreen}
        className="fixed top-3 right-3 z-50 p-2 sm:p-2.5 bg-[#FAF6F0] text-[#1C1917] rounded-full border border-[#DECDBA] shadow-xl hover:bg-white transition-all text-xs flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
        title="Exit Fullscreen Clean Banner View"
      >
        <Minimize2 className="w-4 h-4" />
        <span className="hidden sm:inline">Exit Fullscreen</span>
      </button>
    );
  }

  return (
    <aside
      aria-label="Studio controls"
      className="sticky top-0 z-40 w-full bg-[#FAF6F0]/95 backdrop-blur-xl border-b border-[#DECDBA] py-2 px-3 sm:px-8 transition-all text-[#1C1917]"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-3 text-xs">
        {/* Left: Indicator & Quick Info */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-[#78350F] animate-pulse" />
          <span className="font-bold text-[#1C1917] tracking-tight text-[11px] sm:text-xs">
            Studio Controls
          </span>
          <span className="hidden lg:inline text-[#A89A88]">|</span>
          <span className="hidden lg:inline text-[#78716C] font-medium text-xs">
            Light Brown Timber Palette
          </span>
        </div>

        {/* Center / Right: Compact Touch-Friendly Controls on Mobile */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 overflow-x-auto no-scrollbar py-0.5">
          {/* Background Variant Selector */}
          <div className="flex items-center bg-[#EDE5DB] border border-[#DECDBA] rounded-lg p-0.5 shrink-0">
            <button
              onClick={() => onBackgroundModeChange('with-log')}
              className={`px-2 sm:px-2.5 py-1 rounded-md transition-all flex items-center gap-1 cursor-pointer text-[11px] sm:text-xs ${
                backgroundMode === 'with-log'
                  ? 'bg-[#1C1917] text-white font-semibold shadow'
                  : 'text-[#78716C] hover:text-[#1C1917]'
              }`}
              title="Handcrafted tree trunk log wine rack holder"
            >
              <Palette className="w-3 h-3" />
              <span>Log Visual</span>
            </button>

            <button
              onClick={() => onBackgroundModeChange('pure-black')}
              className={`px-2 sm:px-2.5 py-1 rounded-md transition-all flex items-center gap-1 cursor-pointer text-[11px] sm:text-xs ${
                backgroundMode === 'pure-black'
                  ? 'bg-[#1C1917] text-white font-semibold shadow'
                  : 'text-[#78716C] hover:text-[#1C1917]'
              }`}
              title="Clean background without photo"
            >
              <span>Minimal</span>
            </button>
          </div>

          {/* Aspect Frame Selector (Desktop only) */}
          <div className="hidden lg:flex items-center bg-[#EDE5DB] border border-[#DECDBA] rounded-lg p-0.5 shrink-0">
            <button
              onClick={() => onAspectModeChange('full-viewport')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                aspectMode === 'full-viewport'
                  ? 'bg-[#1C1917] text-white font-semibold shadow'
                  : 'text-[#78716C] hover:text-[#1C1917]'
              }`}
            >
              Full Screen
            </button>
            <button
              onClick={() => onAspectModeChange('contained-16-9')}
              className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                aspectMode === 'contained-16-9'
                  ? 'bg-[#1C1917] text-white font-semibold shadow'
                  : 'text-[#78716C] hover:text-[#1C1917]'
              }`}
            >
              16:9 Frame
            </button>
          </div>

          {/* Quick Jump Buttons (Desktop & Tablet) */}
          {onJumpToStory && (
            <button
              onClick={onJumpToStory}
              className="hidden sm:flex px-2 sm:px-2.5 py-1 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors items-center gap-1 cursor-pointer font-medium text-[11px] sm:text-xs shrink-0"
              title="Jump to Section 2: Our Story"
            >
              <span>Our Story</span>
            </button>
          )}

          {onJumpToCollections && (
            <button
              onClick={onJumpToCollections}
              className="hidden sm:flex px-2 sm:px-2.5 py-1 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors items-center gap-1 cursor-pointer font-medium text-[11px] sm:text-xs shrink-0"
              title="Jump to Section 3: Collections"
            >
              <span>Collections</span>
            </button>
          )}

          {onJumpToCommunity && (
            <button
              onClick={onJumpToCommunity}
              className="hidden md:flex px-2 sm:px-2.5 py-1 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors items-center gap-1 cursor-pointer font-medium text-[11px] sm:text-xs shrink-0"
              title="Jump to Community"
            >
              <span>Community</span>
            </button>
          )}

          {/* Edit Copy Toggle */}
          <button
            onClick={onToggleEdit}
            className={`px-2 sm:px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1 cursor-pointer text-[11px] sm:text-xs shrink-0 ${
              isEditing
                ? 'bg-[#1C1917] text-white border-[#1C1917] font-semibold'
                : 'bg-[#EDE5DB] text-[#57534E] border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917]'
            }`}
          >
            <Sliders className="w-3 h-3" />
            <span>{isEditing ? 'Done' : 'Edit'}</span>
          </button>

          {/* Compare Reference Button (Tablet & Desktop) */}
          <button
            onClick={onOpenCompare}
            className="hidden sm:flex px-2 sm:px-2.5 py-1 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors items-center gap-1 cursor-pointer shrink-0"
            title="Compare with Reference Screenshot"
          >
            <Eye className="w-3 h-3" />
            <span className="hidden md:inline">Compare</span>
          </button>

          {/* Code Viewer (Tablet & Desktop) */}
          <button
            onClick={onOpenCode}
            className="hidden sm:flex px-2 sm:px-2.5 py-1 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors items-center gap-1 cursor-pointer shrink-0"
            title="View Code Snippet"
          >
            <FileCode className="w-3 h-3" />
            <span className="hidden md:inline">Code</span>
          </button>

          {/* Export PNG */}
          <button
            onClick={onDownloadPng}
            disabled={isDownloading}
            className="px-2.5 sm:px-3 py-1 rounded-lg bg-[#1C1917] text-white font-semibold hover:bg-[#292524] transition-colors flex items-center gap-1 shadow disabled:opacity-50 cursor-pointer text-[11px] sm:text-xs shrink-0"
            title="Download high-resolution image of banner"
          >
            <Download className="w-3 h-3" />
            <span>{isDownloading ? '...' : 'PNG'}</span>
          </button>

          {/* Fullscreen Mode */}
          <button
            onClick={onToggleFullscreen}
            className="p-1 sm:p-1.5 rounded-lg bg-[#EDE5DB] text-[#57534E] border border-[#DECDBA] hover:text-[#1C1917] hover:border-[#1C1917] transition-colors cursor-pointer shrink-0"
            title="Toggle Clean Fullscreen View"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
