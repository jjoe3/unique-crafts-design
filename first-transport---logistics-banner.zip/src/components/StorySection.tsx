import React from 'react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import { useInView } from '../hooks/useInView.ts';

interface StorySectionProps {
  onExploreClick?: () => void;
}

const liveEdgeMirrorImg = '/src/assets/images/live_edge_mirror_outdoor_1791623557138.jpg';

export const StorySection: React.FC<StorySectionProps> = ({ onExploreClick }) => {
  const { ref, isInView } = useInView<HTMLElement>({ threshold: 0.1 });

  return (
    <section
      ref={ref}
      id="our-story"
      className="relative w-full py-16 sm:py-24 md:py-32 px-4 sm:px-8 md:px-16 lg:px-20 border-t border-[#D6C7B2] overflow-hidden select-none text-[#1C1917]"
      style={{ backgroundColor: '#EDE5DB' }}
    >
      <div
        className={`max-w-7xl mx-auto transition-all duration-700 ease-out transform ${
          isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-14 items-center">
          {/* LEFT SIDE: Handcrafted Live-Edge Mirror Photo */}
          <div
            className={`lg:col-span-5 flex flex-col justify-center transition-all duration-700 delay-100 ease-out transform ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <div className="relative group rounded-2xl overflow-hidden border border-[#DECDBA] bg-[#FAF6F0] shadow-xl max-w-md mx-auto lg:max-w-none w-full">
              <img
                src={liveEdgeMirrorImg}
                alt="Handcrafted live-edge walnut wood mirror reflecting nature outdoors"
                className="w-full h-full object-cover aspect-[3/4] max-h-[380px] sm:max-h-[500px] lg:max-h-[620px] group-hover:scale-[1.02] transition-transform duration-500"
                referrerPolicy="no-referrer"
              />

              {/* Studio caption badge */}
              <div className="absolute bottom-3 sm:bottom-4 left-3 sm:left-4 right-3 sm:right-4 p-3 sm:p-3.5 rounded-xl bg-[#FAF6F0]/90 backdrop-blur-md border border-[#DECDBA] text-left shadow-sm">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#78716C] block">
                  Studio Creation
                </span>
                <span className="text-xs font-bold text-[#1C1917] block mt-0.5">
                  Natural Live-Edge Mirror · Organic Walnut Slab
                </span>
              </div>
            </div>
          </div>

          {/* RIGHT SIDE: All Requested Texts */}
          <div
            className={`lg:col-span-7 flex flex-col justify-center text-left transition-all duration-700 delay-200 ease-out transform ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            {/* Kicker / Category Tag */}
            <div className="flex items-center gap-3 mb-3 sm:mb-4">
              <span className="text-xs sm:text-sm font-bold uppercase tracking-[0.25em] text-[#1C1917]">
                OUR STORY
              </span>
              <span className="h-[1px] w-8 bg-[#A89A88]" />
              <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
                Hero
              </span>
            </div>

            {/* Heading: Every Piece Starts With a Story. */}
            <h2 className="banner-heading text-2xl sm:text-4xl md:text-5xl lg:text-[54px] font-extrabold text-[#1C1917] tracking-tight leading-[1.12] mb-4 sm:mb-6">
              Every Piece Starts With a Story.
            </h2>

            {/* Introductory Lead Line */}
            <p className="text-sm sm:text-base md:text-lg text-[#292524] font-medium leading-relaxed mb-6 sm:mb-8 max-w-2xl border-l-2 border-[#1C1917] pl-3.5 sm:pl-4 py-1">
              Before it becomes a piece of furniture or décor, it begins as wood shaped by nature.
            </p>

            {/* Sub-label: Our story */}
            <div className="mb-3 sm:mb-4">
              <h3 className="text-xs sm:text-sm uppercase tracking-[0.2em] font-bold text-[#1C1917]">
                Our story
              </h3>
            </div>

            {/* Narrative Paragraphs */}
            <div className="space-y-4 sm:space-y-5 text-[#44403C] text-[14.5px] sm:text-base leading-relaxed max-w-2xl banner-subheading">
              <p>
                Unique Crafts Design was born from a simple idea: beautiful natural materials deserve to be seen, not hidden.
              </p>

              <p>
                We select distinctive pieces of wood and allow their natural character to guide the design. Instead of forcing every piece into the same shape, we work with its curves, grain, imperfections, and live edges.
              </p>

              <p className="text-[#1C1917] font-semibold text-[15px] sm:text-[17px]">
                The result is handcrafted décor that feels authentic, personal, and completely unique.
              </p>
            </div>

            {/* Subtle Craftsmanship Attributes */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mt-8 sm:mt-10 pt-6 sm:pt-8 border-t border-[#D6C7B2]">
              <div className="p-3.5 sm:p-4 rounded-xl bg-[#FAF6F0] border border-[#DECDBA] shadow-sm">
                <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-[#78716C] block mb-1">
                  Material
                </span>
                <span className="text-sm font-bold text-[#1C1917] block">
                  Natural Timber
                </span>
                <span className="text-[11px] text-[#57534E] mt-0.5 block">
                  Preserved organic grain
                </span>
              </div>

              <div className="p-3.5 sm:p-4 rounded-xl bg-[#FAF6F0] border border-[#DECDBA] shadow-sm">
                <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-[#78716C] block mb-1">
                  Philosophy
                </span>
                <span className="text-sm font-bold text-[#1C1917] block">
                  Live Edges
                </span>
                <span className="text-[11px] text-[#57534E] mt-0.5 block">
                  Zero forced geometry
                </span>
              </div>

              <div className="p-3.5 sm:p-4 rounded-xl bg-[#FAF6F0] border border-[#DECDBA] shadow-sm">
                <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-[#78716C] block mb-1">
                  Outcome
                </span>
                <span className="text-sm font-bold text-[#1C1917] block">
                  100% Unique
                </span>
                <span className="text-[11px] text-[#57534E] mt-0.5 block">
                  Authentic & personal
                </span>
              </div>
            </div>

            {/* Action Button & Trust Marker */}
            <div className="mt-7 sm:mt-8 flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-5">
              <button
                onClick={onExploreClick}
                className="group inline-flex items-center justify-center gap-3 bg-[#1C1917] text-white pl-6 pr-3 py-3 rounded-full font-semibold text-sm hover:bg-[#292524] transition-all duration-200 cursor-pointer shadow-lg w-full sm:w-auto"
              >
                <span>Explore Handcrafted Collection</span>
                <span className="flex items-center justify-center w-7 h-7 rounded-full bg-white text-black group-hover:translate-x-0.5 transition-transform duration-200">
                  <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
                </span>
              </button>

              <div className="text-xs text-[#57534E] flex items-center justify-center sm:justify-start gap-2 font-medium">
                <ShieldCheck className="w-4 h-4 text-[#1C1917]" />
                <span>Handcrafted with sustainable care</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
