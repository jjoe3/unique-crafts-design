import React, { useState } from 'react';
import { X, Copy, Check } from 'lucide-react';

interface CodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeModal: React.FC<CodeModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const codeSnippet = `<!-- First Transport Banner (Regenerated: Plain Black Background, White Elements) -->
<section class="relative w-full min-h-screen bg-black text-white overflow-hidden flex flex-col justify-between px-6 sm:px-12 md:px-16 lg:px-20 py-8 sm:py-10 select-none">
  <!-- Top Navigation -->
  <header class="flex items-center justify-between w-full">
    <!-- Logo -->
    <a href="#" class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-full overflow-hidden bg-black border border-amber-800/40 shrink-0">
        <img src="/src/assets/images/unique_crafts_logo_black_bg_1791621209256.jpg" alt="Unique Crafts Design" class="w-full h-full object-cover scale-[1.38]"/>
      </div>
      <div class="flex flex-col leading-none">
        <span class="font-black text-xl tracking-tight text-white font-serif">UNIQUE</span>
        <span class="font-bold text-[8px] text-amber-500 tracking-[0.26em] uppercase mt-0.5">CRAFTS DESIGN</span>
      </div>
    </a>

    <!-- Nav Links -->
    <nav class="hidden md:flex items-center gap-8 text-sm font-normal text-white">
      <a href="#home" class="hover:text-neutral-300">Home</a>
      <a href="#our-story" class="hover:text-neutral-300">Our Story</a>
      <a href="#collections" class="hover:text-neutral-300">Collections</a>
      <a href="#community" class="hover:text-neutral-300">Community</a>
    </nav>
  </header>

  <!-- Hero Content -->
  <main class="my-auto py-12 lg:py-16 max-w-3xl">
    <h1 class="text-4xl sm:text-5xl md:text-6xl lg:text-[72px] font-extrabold text-white tracking-tight leading-[1.08]">
      Every piece begins with wood<br/>
      that already has a story
    </h1>

    <p class="mt-7 max-w-xl text-[15px] sm:text-[17px] text-neutral-200 font-normal leading-relaxed">
      We transform naturally beautiful wood into distinctive pieces designed to bring warmth, character, and craftsmanship into your space.
    </p>

    <div class="mt-9 flex items-center gap-8">
      <a href="#contact" class="inline-flex items-center gap-3.5 bg-white text-black pl-7 pr-3 py-3 rounded-full font-semibold text-sm sm:text-base hover:bg-neutral-100 transition-colors">
        <span>Contact Us</span>
        <span class="flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-black text-white">
          →
        </span>
      </a>
      <a href="#learn-more" class="text-white hover:text-neutral-300 font-normal text-sm sm:text-base transition-colors">
        Learn More
      </a>
    </div>
  </main>

  <!-- Metrics / Proof Bar -->
  <footer class="w-full pt-8 pb-4">
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-8 sm:gap-6 lg:gap-12 max-w-4xl">
      <div>
        <div class="text-4xl sm:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
          100%
        </div>
        <div class="text-xs sm:text-sm text-[#57534E] font-medium mt-3">
          Natural & Salvaged Timber
        </div>
      </div>
      <div>
        <div class="text-4xl sm:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
          500+
        </div>
        <div class="text-xs sm:text-sm text-[#57534E] font-medium mt-3">
          Custom Pieces Handcrafted
        </div>
      </div>
      <div>
        <div class="text-4xl sm:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
          2+
        </div>
        <div class="text-xs sm:text-sm text-[#57534E] font-medium mt-3">
          Years of Woodworking Artistry
        </div>
      </div>
    </div>
  </footer>
</section>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div
        className="relative w-full max-w-3xl max-h-[85vh] flex flex-col bg-[#FAF6F0] border border-[#DECDBA] rounded-2xl p-6 text-[#1C1917] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#78716C] hover:text-[#1C1917] rounded-full hover:bg-[#EDE5DB] transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-between mb-4 pr-10">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-[#1C1917]">Banner Code Snippet</h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Copy this clean Tailwind CSS markup to embed in any web project or page.
            </p>
          </div>
          <button
            onClick={handleCopy}
            className="px-4 py-2 bg-[#1C1917] text-white text-xs font-semibold rounded-lg hover:bg-[#292524] transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        <div className="flex-1 overflow-auto bg-[#F5ECE0] border border-[#DECDBA] rounded-xl p-4 font-mono text-xs text-[#292524] leading-relaxed">
          <pre>{codeSnippet}</pre>
        </div>
      </div>
    </div>
  );
};
