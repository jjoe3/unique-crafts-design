import React, { forwardRef, useState } from 'react';
import { ArrowRight, Menu, X } from 'lucide-react';
import { Logo } from './Logo.tsx';

export interface BannerData {
  headlineLine1: string;
  headlineLine2: string;
  headlineLine3: string;
  description: string;
  primaryCtaText: string;
  secondaryCtaText: string;
  stat1Value: string;
  stat1Label: string;
  stat2Value: string;
  stat2Label: string;
  stat3Value: string;
  stat3Label: string;
}

export const defaultBannerData: BannerData = {
  headlineLine1: 'Every piece begins with wood',
  headlineLine2: 'that already has a story',
  headlineLine3: '',
  description:
    'We transform naturally beautiful wood into distinctive pieces designed to bring warmth, character, and craftsmanship into your space.',
  primaryCtaText: 'Contact Us',
  secondaryCtaText: 'Learn More',
  stat1Value: '100%',
  stat1Label: 'Natural & Salvaged Timber',
  stat2Value: '500+',
  stat2Label: 'Custom Pieces Handcrafted',
  stat3Value: '2+',
  stat3Label: 'Years of Woodworking Artistry',
};

export type BackgroundMode = 'with-log' | 'pure-black' | 'black-spotlight';

interface BannerProps {
  data: BannerData;
  isEditing?: boolean;
  onDataChange?: (key: keyof BannerData, value: string) => void;
  backgroundMode: BackgroundMode;
  onOpenContact: () => void;
  onOpenLearnMore: (tab?: string) => void;
  onNavClick: (navItem: string) => void;
  activeNav?: string;
  aspectMode?: 'contained-16-9' | 'full-viewport';
}

export const Banner = forwardRef<HTMLDivElement, BannerProps>(
  (
    {
      data,
      isEditing = false,
      onDataChange,
      backgroundMode,
      onOpenContact,
      onOpenLearnMore,
      onNavClick,
      activeNav = 'Home',
      aspectMode = 'full-viewport',
    },
    ref
  ) => {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const handleTextChange = (key: keyof BannerData, value: string) => {
      if (onDataChange) {
        onDataChange(key, value);
      }
    };

    const handleMobileNav = (item: string) => {
      setMobileMenuOpen(false);
      onNavClick(item);
    };

    return (
      <div
        ref={ref}
        id="hero-banner"
        className={`relative w-full overflow-hidden text-[#1C1917] select-none transition-colors duration-500 ${
          aspectMode === 'contained-16-9'
            ? 'aspect-[16/9] min-h-[580px] max-w-[1440px] mx-auto rounded-xl shadow-2xl border border-[#D6C7B2]'
            : 'min-h-[100dvh]'
        }`}
        style={{ backgroundColor: '#EDE5DB' }}
      >
        {/* Hero Handcrafted Log Wine Holder Visual - Perfectly Blended for Desktop & Mobile */}
        {backgroundMode !== 'pure-black' && (
          <div className="absolute right-0 top-0 bottom-0 w-full md:w-[72%] lg:w-[64%] pointer-events-none z-0 flex items-center justify-end overflow-hidden">
            <img
              src="/src/assets/images/log_wine_holder_hero_1791624119324.jpg"
              alt="Handcrafted natural tree trunk log wine rack holder with inserted wine bottles"
              className="h-full w-full object-cover object-right-bottom sm:object-right scale-105 transition-all duration-700 opacity-35 sm:opacity-95"
              referrerPolicy="no-referrer"
            />
            {/* Seamless multi-stop blending gradients into light brown background */}
            <div className="absolute inset-y-0 left-0 w-full sm:w-[55%] bg-gradient-to-r from-[#EDE5DB] via-[#EDE5DB]/90 to-transparent pointer-events-none" />
            <div className="absolute inset-x-0 top-0 h-32 sm:h-36 bg-gradient-to-b from-[#EDE5DB] via-[#EDE5DB]/60 to-transparent pointer-events-none" />
            <div className="absolute inset-x-0 bottom-0 h-36 sm:h-44 bg-gradient-to-t from-[#EDE5DB] via-[#EDE5DB]/85 to-transparent pointer-events-none" />
          </div>
        )}

        {/* Content Container - Responsive Padding for Clean Mobile Fit */}
        <div className="relative z-10 flex flex-col justify-between h-full min-h-[100dvh] px-4 sm:px-8 md:px-16 lg:px-20 py-6 sm:py-10">
          {/* 1. TOP NAVIGATION BAR */}
          <header className="flex items-center justify-between w-full relative">
            {/* Brand Logo Lockup */}
            <div onClick={() => onNavClick('Home')}>
              <Logo size="md" />
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-7 lg:gap-9 text-[14.5px] font-medium text-[#292524]">
              {['Home', 'Our Story', 'Collections', 'Community'].map((item) => (
                <button
                  key={item}
                  onClick={() => onNavClick(item)}
                  className={`transition-colors duration-150 relative py-1 cursor-pointer ${
                    activeNav === item
                      ? 'text-[#1C1917] font-bold'
                      : 'text-[#57534E] hover:text-[#1C1917]'
                  }`}
                >
                  {item}
                  {activeNav === item && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#1C1917] rounded-full" />
                  )}
                </button>
              ))}
            </nav>

            {/* Mobile Hamburger Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl bg-[#FAF6F0] border border-[#DECDBA] text-[#1C1917] hover:bg-white transition-colors cursor-pointer shadow-sm"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Top Right Spacer for balanced nav on desktop */}
            <div className="hidden md:block w-8" />
          </header>

          {/* Mobile Navigation Dropdown Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-3 p-4 rounded-2xl bg-[#FAF6F0] border border-[#DECDBA] shadow-xl z-50 flex flex-col gap-2.5 animate-in fade-in slide-in-from-top-2 duration-200">
              {['Home', 'Our Story', 'Collections', 'Community'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleMobileNav(item)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl font-semibold text-sm transition-colors cursor-pointer flex items-center justify-between ${
                    activeNav === item
                      ? 'bg-[#1C1917] text-white'
                      : 'text-[#292524] hover:bg-[#EDE5DB]'
                  }`}
                >
                  <span>{item}</span>
                  <ArrowRight className="w-3.5 h-3.5 opacity-60" />
                </button>
              ))}
            </div>
          )}

          {/* 2. MAIN HERO BODY - HEADLINE, PARAGRAPH & CTAS */}
          <main className="my-auto py-8 sm:py-12 lg:py-16 max-w-3xl">
            {/* Headline */}
            <h1 className="banner-heading text-[32px] sm:text-5xl md:text-6xl lg:text-[72px] font-extrabold text-[#1C1917] tracking-tight leading-[1.12]">
              {isEditing ? (
                <div className="space-y-1">
                  <input
                    type="text"
                    value={data.headlineLine1}
                    onChange={(e) => handleTextChange('headlineLine1', e.target.value)}
                    className="w-full bg-[#FAF6F0] border border-[#DECDBA] px-2 rounded text-[#1C1917]"
                  />
                  <input
                    type="text"
                    value={data.headlineLine2}
                    onChange={(e) => handleTextChange('headlineLine2', e.target.value)}
                    className="w-full bg-[#FAF6F0] border border-[#DECDBA] px-2 rounded text-[#1C1917]"
                  />
                  <input
                    type="text"
                    value={data.headlineLine3}
                    onChange={(e) => handleTextChange('headlineLine3', e.target.value)}
                    className="w-full bg-[#FAF6F0] border border-[#DECDBA] px-2 rounded text-[#1C1917]"
                  />
                </div>
              ) : (
                <>
                  {data.headlineLine1 && <span className="block">{data.headlineLine1}</span>}
                  {data.headlineLine2 && <span className="block">{data.headlineLine2}</span>}
                  {data.headlineLine3 && <span className="block">{data.headlineLine3}</span>}
                </>
              )}
            </h1>

            {/* Description Subtext */}
            <div className="mt-5 sm:mt-7 max-w-xl">
              {isEditing ? (
                <textarea
                  rows={4}
                  value={data.description}
                  onChange={(e) => handleTextChange('description', e.target.value)}
                  className="w-full bg-[#FAF6F0] border border-[#DECDBA] p-2 rounded text-sm text-[#292524]"
                />
              ) : (
                <p className="banner-subheading text-[14.5px] sm:text-[16px] md:text-[17px] text-[#44403C] font-normal leading-relaxed">
                  {data.description}
                </p>
              )}
            </div>

            {/* CTAs: Contact Us (Pill with right arrow) and Learn More */}
            <div className="mt-7 sm:mt-9 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 sm:gap-7">
              {/* Primary Contact Us Button with dark arrow inside circle */}
              <button
                onClick={() => onOpenContact()}
                className="group inline-flex items-center justify-center gap-3.5 bg-[#1C1917] text-white pl-6 sm:pl-7 pr-3 py-3 rounded-full font-semibold text-sm sm:text-[15.5px] hover:bg-[#292524] transition-all duration-200 shadow-xl hover:shadow-2xl cursor-pointer"
              >
                <span>{data.primaryCtaText}</span>
                <span className="flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white text-black transition-transform group-hover:translate-x-0.5 duration-200">
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
                </span>
              </button>

              {/* Secondary Learn More Action */}
              <button
                onClick={() => onOpenLearnMore()}
                className="text-[#1C1917] hover:text-black font-semibold text-sm sm:text-[15.5px] tracking-normal transition-colors cursor-pointer py-2 inline-flex items-center justify-center group"
              >
                <span className="group-hover:underline underline-offset-4 decoration-[#78350F]">
                  {data.secondaryCtaText}
                </span>
              </button>
            </div>
          </main>

          {/* 3. BOTTOM METRICS & PROOF BAR - Compact 3-Column Fit on Mobile */}
          <footer className="w-full pt-6 sm:pt-8 pb-3 sm:pb-4 border-t border-[#D6C7B2]/70">
            <div className="grid grid-cols-3 gap-2 sm:gap-6 lg:gap-12 max-w-4xl text-left">
              {/* Stat 1 */}
              <div className="flex flex-col">
                {isEditing ? (
                  <>
                    <input
                      type="text"
                      value={data.stat1Value}
                      onChange={(e) => handleTextChange('stat1Value', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-1 rounded text-lg sm:text-2xl font-bold text-[#1C1917]"
                    />
                    <input
                      type="text"
                      value={data.stat1Label}
                      onChange={(e) => handleTextChange('stat1Label', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-0.5 rounded text-[10px] sm:text-xs mt-1 text-[#44403C]"
                    />
                  </>
                ) : (
                  <>
                    <div className="text-2xl sm:text-4xl md:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
                      {data.stat1Value}
                    </div>
                    <div className="text-[10px] sm:text-xs md:text-[13px] text-[#57534E] font-medium mt-1 sm:mt-2 tracking-wide leading-tight sm:leading-snug">
                      {data.stat1Label}
                    </div>
                  </>
                )}
              </div>

              {/* Stat 2 */}
              <div className="flex flex-col">
                {isEditing ? (
                  <>
                    <input
                      type="text"
                      value={data.stat2Value}
                      onChange={(e) => handleTextChange('stat2Value', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-1 rounded text-lg sm:text-2xl font-bold text-[#1C1917]"
                    />
                    <input
                      type="text"
                      value={data.stat2Label}
                      onChange={(e) => handleTextChange('stat2Label', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-0.5 rounded text-[10px] sm:text-xs mt-1 text-[#44403C]"
                    />
                  </>
                ) : (
                  <>
                    <div className="text-2xl sm:text-4xl md:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
                      {data.stat2Value}
                    </div>
                    <div className="text-[10px] sm:text-xs md:text-[13px] text-[#57534E] font-medium mt-1 sm:mt-2 tracking-wide leading-tight sm:leading-snug">
                      {data.stat2Label}
                    </div>
                  </>
                )}
              </div>

              {/* Stat 3 */}
              <div className="flex flex-col">
                {isEditing ? (
                  <>
                    <input
                      type="text"
                      value={data.stat3Value}
                      onChange={(e) => handleTextChange('stat3Value', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-1 rounded text-lg sm:text-2xl font-bold text-[#1C1917]"
                    />
                    <input
                      type="text"
                      value={data.stat3Label}
                      onChange={(e) => handleTextChange('stat3Label', e.target.value)}
                      className="bg-[#FAF6F0] border border-[#DECDBA] px-2 py-0.5 rounded text-[10px] sm:text-xs mt-1 text-[#44403C]"
                    />
                  </>
                ) : (
                  <>
                    <div className="text-2xl sm:text-4xl md:text-5xl lg:text-[56px] font-extrabold text-[#1C1917] tracking-tight leading-none">
                      {data.stat3Value}
                    </div>
                    <div className="text-[10px] sm:text-xs md:text-[13px] text-[#57534E] font-medium mt-1 sm:mt-2 tracking-wide leading-tight sm:leading-snug max-w-[240px]">
                      {data.stat3Label}
                    </div>
                  </>
                )}
              </div>
            </div>
          </footer>
        </div>
      </div>
    );
  }
);

Banner.displayName = 'Banner';
