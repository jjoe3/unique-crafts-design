import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView.ts';

interface CollectionsSectionProps {
  onSelectCollection?: (title: string) => void;
  onCustomProjectClick?: () => void;
}

const wineHolderImg = '/src/assets/images/wine_holder_live_edge_1791279561974.jpg';
const mirrorImg = '/src/assets/images/natural_wood_mirror_1791279572934.jpg';
const wallArtImg = '/src/assets/images/wooden_branch_wall_art_1791279583835.jpg';
const customTableImg = '/src/assets/images/custom_stump_glass_table_1791279591966.jpg';

export const CollectionsSection: React.FC<CollectionsSectionProps> = ({
  onSelectCollection,
  onCustomProjectClick,
}) => {
  const { ref, isInView } = useInView<HTMLElement>({ threshold: 0.08 });

  const collections = [
    {
      id: 'wine',
      category: 'Wine & Entertaining',
      heading: 'Wine Holders',
      description:
        'Turn your favorite bottles into part of the décor. Our handcrafted wine holders combine natural live-edge wood with practical design to create a distinctive display.',
      buttonText: 'Explore Wine Holders',
      image: wineHolderImg,
    },
    {
      id: 'mirrors',
      category: 'Mirrors',
      heading: 'Natural Wood Mirrors',
      description:
        'Organic wood frames meet clean reflective surfaces, creating statement pieces that bring warmth and texture to any room.',
      buttonText: 'Explore Mirrors',
      image: mirrorImg,
    },
    {
      id: 'wall-art',
      category: 'Wall Art',
      heading: 'Wooden Wall Art',
      description:
        'Sculptural pieces created from naturally beautiful wood, designed to give empty walls a sense of character and story.',
      buttonText: 'Explore Wall Art',
      image: wallArtImg,
    },
  ];

  return (
    <section
      ref={ref}
      id="collections"
      className="relative w-full py-16 sm:py-24 md:py-32 px-4 sm:px-8 md:px-16 lg:px-20 border-t border-[#D6C7B2] overflow-hidden select-none text-[#1C1917]"
      style={{ backgroundColor: '#EDE5DB' }}
    >
      <div
        className={`max-w-7xl mx-auto transition-all duration-700 ease-out transform ${
          isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        {/* SECTION HEADER / HERO */}
        <div className="text-left max-w-3xl mb-12 sm:mb-16 lg:mb-20">
          <div className="flex items-center gap-3 mb-3 sm:mb-4">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-[0.25em] text-[#1C1917]">
              3. COLLECTIONS
            </span>
            <span className="h-[1px] w-8 bg-[#A89A88]" />
            <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
              Hero
            </span>
          </div>

          <h2 className="banner-heading text-3xl sm:text-4xl lg:text-[62px] font-extrabold text-[#1C1917] tracking-tight leading-[1.1]">
            The Collection
          </h2>

          <p className="banner-subheading text-base sm:text-lg lg:text-xl text-[#44403C] font-normal mt-3 sm:mt-4 leading-relaxed max-w-2xl">
            Functional pieces shaped by nature and finished by hand.
          </p>
        </div>

        {/* 3 PRIMARY COLLECTIONS: WINE HOLDERS, MIRRORS, WOODEN WALL ART */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6 lg:gap-8 mb-16 sm:mb-20 lg:mb-24">
          {collections.map((item, index) => (
            <div
              key={item.id}
              style={{ transitionDelay: `${index * 120 + 100}ms` }}
              className={`group flex flex-col justify-between p-5 sm:p-7 rounded-2xl bg-[#FAF6F0] border border-[#DECDBA] hover:border-[#B59F85] transition-all duration-700 ease-out shadow-sm hover:shadow-md transform ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
            >
              <div>
                {/* Product Visual (100px) */}
                <div className="relative w-[100px] h-[100px] rounded-xl overflow-hidden bg-[#E8DCCF] border border-[#D6C7B2] mb-4 sm:mb-5 shrink-0 shadow-sm group-hover:border-[#78350F] transition-colors">
                  <img
                    src={item.image}
                    alt={item.heading}
                    className="w-[100px] h-[100px] object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Text & Content */}
                <div className="text-left">
                  <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-widest text-[#78716C] block mb-1">
                    {item.category}
                  </span>
                  <h3 className="banner-heading text-lg sm:text-xl lg:text-2xl font-bold text-[#1C1917] tracking-tight mb-2 sm:mb-2.5">
                    {item.heading}
                  </h3>
                  <p className="banner-subheading text-xs sm:text-sm text-[#57534E] leading-relaxed mb-5 sm:mb-6 font-normal">
                    {item.description}
                  </p>
                </div>
              </div>

              {item.buttonText && (
                <button
                  onClick={() => onSelectCollection?.(item.heading)}
                  className="inline-flex items-center justify-between w-full px-4 sm:px-5 py-2.5 rounded-full bg-[#1C1917] text-white hover:bg-[#292524] font-semibold text-xs sm:text-sm tracking-wide transition-all duration-200 cursor-pointer group/btn shadow-sm"
                >
                  <span>{item.buttonText}</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* CUSTOM PIECES: PICTURES 50PX (2 ON LEFT, 2 ON RIGHT ON DESKTOP, INTEGRATED ON MOBILE) */}
        <div
          style={{ transitionDelay: '400ms' }}
          className={`relative rounded-2xl bg-[#F5ECE0] border border-[#DECDBA] p-6 sm:p-10 lg:p-12 shadow-sm overflow-hidden transition-all duration-700 ease-out transform ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          {/* Subtle background ambient line */}
          <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-[#C4B5A2] to-transparent" />

          <div className="flex flex-col lg:flex-row items-center justify-between gap-6 sm:gap-10 lg:gap-12 text-center lg:text-left">
            {/* 2 PICTURES (50px) ON THE LEFT */}
            <div className="flex items-center justify-center gap-3 shrink-0 order-2 lg:order-1">
              <div
                className="w-[50px] h-[50px] rounded-xl overflow-hidden border border-[#DECDBA] bg-[#E8DCCF] shadow-sm shrink-0 group relative cursor-pointer"
                title="Wine Holder Design"
              >
                <img
                  src={wineHolderImg}
                  alt="Wine Holder thumbnail 50px"
                  className="w-[50px] h-[50px] object-cover group-hover:scale-110 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div
                className="w-[50px] h-[50px] rounded-xl overflow-hidden border border-[#DECDBA] bg-[#E8DCCF] shadow-sm shrink-0 group relative cursor-pointer"
                title="Natural Mirror Design"
              >
                <img
                  src={mirrorImg}
                  alt="Mirror thumbnail 50px"
                  className="w-[50px] h-[50px] object-cover group-hover:scale-110 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* CENTER: CUSTOM PIECES TEXT CONTENT */}
            <div className="flex-1 max-w-2xl order-1 lg:order-2">
              <span className="text-[11px] sm:text-xs uppercase tracking-[0.25em] font-bold text-[#78716C] block mb-1.5 sm:mb-2">
                Custom Pieces
              </span>

              {/* Heading: Made For Your Space */}
              <h3 className="banner-heading text-xl sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-[#1C1917] tracking-tight leading-tight mb-2 sm:mb-3">
                Made For Your Space
              </h3>

              {/* Text */}
              <p className="banner-subheading text-xs sm:text-sm md:text-base text-[#44403C] font-normal leading-relaxed mb-5 sm:mb-6">
                Looking for something different? Tell us what you have in mind and we'll explore how natural wood can bring your idea to life.
              </p>

              {/* Button: Start a Custom Project */}
              <button
                onClick={onCustomProjectClick}
                className="inline-flex items-center justify-center gap-3 bg-[#1C1917] text-white pl-6 pr-3.5 py-3 rounded-full font-semibold text-xs sm:text-sm hover:bg-[#292524] transition-all duration-200 cursor-pointer shadow-lg group w-full sm:w-auto"
              >
                <span>Start a Custom Project</span>
                <span className="flex items-center justify-center w-7 h-7 rounded-full bg-white text-black group-hover:translate-x-0.5 transition-transform duration-200">
                  <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
                </span>
              </button>
            </div>

            {/* 2 PICTURES (50px) ON THE RIGHT */}
            <div className="flex items-center justify-center gap-3 shrink-0 order-3">
              <div
                className="w-[50px] h-[50px] rounded-xl overflow-hidden border border-[#DECDBA] bg-[#E8DCCF] shadow-sm shrink-0 group relative cursor-pointer"
                title="Wooden Wall Art Design"
              >
                <img
                  src={wallArtImg}
                  alt="Wall Art thumbnail 50px"
                  className="w-[50px] h-[50px] object-cover group-hover:scale-110 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div
                className="w-[50px] h-[50px] rounded-xl overflow-hidden border border-[#DECDBA] bg-[#E8DCCF] shadow-sm shrink-0 group relative cursor-pointer"
                title="Custom Live Edge Table Design"
              >
                <img
                  src={customTableImg}
                  alt="Custom Table thumbnail 50px"
                  className="w-[50px] h-[50px] object-cover group-hover:scale-110 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
