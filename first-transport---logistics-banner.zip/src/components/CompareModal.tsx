import React from 'react';
import { X, Check } from 'lucide-react';

interface CompareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div
        className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto bg-[#FAF6F0] border border-[#DECDBA] rounded-2xl p-6 sm:p-8 text-[#1C1917] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#78716C] hover:text-[#1C1917] rounded-full hover:bg-[#EDE5DB] transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
            Quality & Fidelity Verification
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1 text-[#1C1917]">
            Reference vs Studio Design
          </h2>
          <p className="text-sm text-[#57534E] mt-1">
            All text, navigation, and typography are precisely arranged with an organic light brown timber palette.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          {/* Original Reference */}
          <div className="p-4 rounded-xl bg-[#F5ECE0] border border-[#DECDBA] flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#1C1917]">
                Original Reference Image
              </span>
              <span className="text-[11px] text-[#78716C]">Initial Layout</span>
            </div>
            <div className="rounded-lg overflow-hidden border border-[#DECDBA] bg-black aspect-[16/11]">
              <img
                src="Screenshot 2026-10-06 114300.png"
                alt="Reference Banner"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <ul className="mt-4 space-y-2 text-xs text-[#57534E]">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#78350F]" />
                Original 3-part layout: Top bar, Left hero, Bottom metrics
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#78350F]" />
                Clean geometric sans typography and pill button design
              </li>
            </ul>
          </div>

          {/* Unique Crafts Design */}
          <div className="p-4 rounded-xl bg-[#F5ECE0] border border-[#DECDBA] flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#1C1917]">
                Unique Crafts Design
              </span>
              <span className="text-[11px] text-[#78350F] font-bold">Light Brown Theme</span>
            </div>
            <div className="rounded-lg overflow-hidden border border-[#DECDBA] bg-[#EDE5DB] aspect-[16/11] p-4 flex flex-col justify-between">
              {/* Mini preview */}
              <div className="flex justify-between items-center text-[10px] text-[#57534E] border-b border-[#DECDBA] pb-2">
                <span className="font-bold text-[#1C1917]">UNIQUE CRAFTS</span>
                <span className="space-x-2 hidden sm:inline">
                  <span>Home</span>
                  <span>Our Story</span>
                  <span>Collections</span>
                </span>
                <span className="text-[#78350F] text-[9px] font-bold">Studio</span>
              </div>
              <div className="py-2">
                <div className="text-xs font-extrabold text-[#1C1917] leading-tight">
                  Every piece begins with wood<br />that already has a story
                </div>
                <div className="text-[9px] text-[#57534E] mt-1 line-clamp-2">
                  We transform naturally beautiful wood into distinctive pieces...
                </div>
                <div className="mt-2 inline-flex items-center gap-1.5 bg-[#1C1917] text-white px-2.5 py-1 rounded-full text-[9px] font-bold">
                  <span>Contact Us</span>
                  <span className="w-3.5 h-3.5 rounded-full bg-white text-black flex items-center justify-center text-[8px]">→</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 border-t border-[#DECDBA] pt-2 text-[8px]">
                <div>
                  <div className="font-extrabold text-[#1C1917] text-[11px]">100%</div>
                  <div className="text-[#57534E]">Natural Timber</div>
                </div>
                <div>
                  <div className="font-extrabold text-[#1C1917] text-[11px]">500+</div>
                  <div className="text-[#57534E]">Handcrafted</div>
                </div>
                <div>
                  <div className="font-extrabold text-[#1C1917] text-[11px]">2+</div>
                  <div className="text-[#57534E]">Years Artistry</div>
                </div>
              </div>
            </div>
            <ul className="mt-4 space-y-2 text-xs text-[#57534E]">
              <li className="flex items-center gap-2 text-[#1C1917]">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Warm, organic light brown background applied to all pages
              </li>
              <li className="flex items-center gap-2 text-[#1C1917]">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Natural round log cross-section blended into hero
              </li>
              <li className="flex items-center gap-2 text-[#1C1917]">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Artisanal typography and high contrast legibility
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full bg-[#1C1917] text-white font-semibold text-sm hover:bg-[#292524] transition-colors cursor-pointer"
          >
            Back to Studio
          </button>
        </div>
      </div>
    </div>
  );
};
