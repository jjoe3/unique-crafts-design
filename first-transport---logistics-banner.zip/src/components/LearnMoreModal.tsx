import React from 'react';
import { X, TreePine, ShieldCheck, Sparkles, CheckCircle2, Award } from 'lucide-react';

interface LearnMoreModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LearnMoreModal: React.FC<LearnMoreModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div
        className="relative w-full max-w-3xl max-h-[88vh] overflow-y-auto bg-[#FAF6F0] border border-[#DECDBA] rounded-2xl p-6 sm:p-8 text-[#1C1917] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#78716C] hover:text-[#1C1917] rounded-full hover:bg-[#EDE5DB] transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-xs uppercase tracking-widest text-[#78716C] font-semibold">
            Unique Crafts Design · Philosophy & Process
          </span>
          <h2 className="text-3xl font-extrabold tracking-tight mt-1 text-[#1C1917]">
            Every Piece Begins With Wood That Already Has a Story
          </h2>
          <p className="text-[#57534E] text-sm mt-2 max-w-2xl leading-relaxed">
            We transform naturally beautiful wood into distinctive pieces designed to bring warmth, character, and craftsmanship into your space. Our artisans preserve organic grains, live edges, and natural contours.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="p-4 rounded-xl bg-[#F5ECE0] border border-[#DECDBA]">
            <div className="w-10 h-10 rounded-lg bg-[#EDE5DB] flex items-center justify-center mb-3 text-[#1C1917] border border-[#DECDBA]">
              <TreePine className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#1C1917] mb-1">Sustainable Timber</h3>
            <p className="text-xs text-[#57534E] leading-relaxed">
              We exclusively select salvaged, reclaimed, and responsibly harvested native hardwood slabs with rich grain patterns.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F5ECE0] border border-[#DECDBA]">
            <div className="w-10 h-10 rounded-lg bg-[#EDE5DB] flex items-center justify-center mb-3 text-[#1C1917] border border-[#DECDBA]">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#1C1917] mb-1">Preserved Live Edges</h3>
            <p className="text-xs text-[#57534E] leading-relaxed">
              Rather than cutting straight manufactured lines, we honor natural tree curves, cracks, bark margins, and knots.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F5ECE0] border border-[#DECDBA]">
            <div className="w-10 h-10 rounded-lg bg-[#EDE5DB] flex items-center justify-center mb-3 text-[#1C1917] border border-[#DECDBA]">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#1C1917] mb-1">Hand-Rubbed Finish</h3>
            <p className="text-xs text-[#57534E] leading-relaxed">
              Finished with organic non-toxic oils and beeswax that bring out the deep depth, chatoyancy, and natural scent of wood.
            </p>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#EDE5DB] border border-[#DECDBA] mb-8">
          <h4 className="font-bold text-sm text-[#1C1917] mb-3 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#78350F]" />
            Artisanal Standards:
          </h4>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-[#44403C]">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#1C1917] shrink-0" />
              <span>Zero mass-produced synthetic laminates</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#1C1917] shrink-0" />
              <span>Individually numbered studio hallmark</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#1C1917] shrink-0" />
              <span>Kiln-dried and moisture stabilized</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#1C1917] shrink-0" />
              <span>Custom dimensions tailored to your interior</span>
            </li>
          </ul>
        </div>

        <div className="flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#1C1917] text-white font-semibold text-sm rounded-full hover:bg-[#292524] transition-colors cursor-pointer"
          >
            Close Overview
          </button>
        </div>
      </div>
    </div>
  );
};
