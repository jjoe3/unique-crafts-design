import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const iconSize = size === 'sm' ? 'w-9 h-9' : size === 'lg' ? 'w-14 h-14' : 'w-11 h-11';
  const titleSize = size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl';
  const subSize = size === 'sm' ? 'text-[7.5px]' : size === 'lg' ? 'text-[9.5px]' : 'text-[8.5px]';

  return (
    <div className={`flex items-center gap-3.5 select-none cursor-pointer group ${className}`}>
      {/* Handcrafted Emblem with Tree, Wood Rings & Carving Chisel */}
      <div
        className={`relative ${iconSize} rounded-full overflow-hidden bg-black border border-amber-900/40 group-hover:border-amber-500/70 transition-all duration-300 shrink-0 shadow-lg`}
      >
        <img
          src="/src/assets/images/unique_crafts_logo_black_bg_1791621209256.jpg"
          alt="Unique Crafts Design Logo Emblem"
          className="w-full h-full object-cover scale-[1.38] -translate-y-[1px] group-hover:scale-[1.45] transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        {/* Soft edge ambient blend */}
        <div className="absolute inset-0 rounded-full border border-white/5 pointer-events-none" />
      </div>

      {/* Brand Typography matching the emblem styling */}
      <div className="flex flex-col leading-none text-left">
        <span
          className={`font-black tracking-[0.06em] text-white font-serif group-hover:text-amber-100 transition-colors ${titleSize}`}
          style={{
            fontFamily: "Georgia, 'Times New Roman', serif",
          }}
        >
          UNIQUE
        </span>
        <span
          className={`font-bold text-amber-500 tracking-[0.26em] uppercase mt-0.5 ${subSize}`}
          style={{
            fontFamily: "'Plus Jakarta Sans', sans-serif",
          }}
        >
          CRAFTS DESIGN
        </span>
      </div>
    </div>
  );
};
