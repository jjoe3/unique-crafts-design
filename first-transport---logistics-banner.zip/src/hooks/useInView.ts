import { useEffect, useRef, useState } from 'react';

interface UseInViewOptions extends IntersectionObserverInit {
  triggerOnce?: boolean;
}

export function useInView<T extends HTMLElement = HTMLElement>(
  options: UseInViewOptions = {}
) {
  const { triggerOnce = true, threshold = 0.12, rootMargin = '0px 0px -40px 0px', root = null } = options;
  const ref = useRef<T>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // Graceful fallback if IntersectionObserver is unavailable or prefers-reduced-motion
    if (typeof IntersectionObserver === 'undefined') {
      setIsInView(true);
      return;
    }

    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      setIsInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          if (triggerOnce) {
            observer.unobserve(entry.target);
          }
        } else if (!triggerOnce) {
          setIsInView(false);
        }
      },
      { threshold, rootMargin, root }
    );

    observer.observe(el);

    return () => {
      observer.disconnect();
    };
  }, [triggerOnce, threshold, rootMargin, root]);

  return { ref, isInView };
}
